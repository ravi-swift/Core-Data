//
//  InsertDataVCViewController.swift
//  CoreDataNewDemo
//
//  Created by WeEnggs Technology on 07/01/20.
//  Copyright © 2020 WeEnggs Technology. All rights reserved.
//

import UIKit
import CoreData

class InsertDataVCViewController: UIViewController,UITextFieldDelegate {

    var activeField: UITextField?
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var userIdTextField: UITextField!
    @IBOutlet weak var genserTextField: UITextField!
    @IBOutlet weak var userAgeTextField: UITextField!
    
    let nscontext = appdelegate?.persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    @IBAction func saveButton(_ sender: UIButton){
        let dict = ["username":userNameTextField.text ?? "","password":passwordTextField.text ?? "","gender":userIdTextField.text ?? "","age":genserTextField.text ?? "","userid":userAgeTextField.text ?? ""] as [String:Any]
        DataBaseHelper.shared.save(object: dict)
     /*   let entrys = NSEntityDescription.insertNewObject(forEntityName: "UserData", into: nscontext!)// coredata name
        entrys.setValue(userNameTextField.text, forKey: "username")
        entrys.setValue(passwordTextField.text, forKey: "password")
        entrys.setValue(userIdTextField.text, forKey: "gender")
        entrys.setValue(genserTextField.text, forKey: "age")
        entrys.setValue(userAgeTextField.text, forKey: "userid")
        do {
            try nscontext?.save()
            userNameTextField.text = ""
            passwordTextField.text = ""
            userIdTextField.text = ""
            genserTextField.text = ""
            userAgeTextField.text = ""
        }
        catch {
            
        }
        print("Record Inserted")
        self.navigationController?.popViewController(animated: true) */
    }
    
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    @objc func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollView.isScrollEnabled = true
        let info = notification.userInfo!
        let keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: keyboardSize!.height, right: 0.0)

        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets

        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollView.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }

    @objc func keyboardWillBeHidden(notification: NSNotification){
        //Once keyboard disappears, restore original positions
        let info = notification.userInfo!
        let keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: -keyboardSize!.height, right: 0.0)
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
        self.view.endEditing(true)
        self.scrollView.isScrollEnabled = false
    }

    func textFieldDidBeginEditing(_ textField: UITextField){
        activeField = textField
    }

    func textFieldDidEndEditing(_ textField: UITextField){
        activeField = nil
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
          // Try to find next responder
          if let nextField = textField.superview?.viewWithTag(textField.tag + 1) as? UITextField {
             nextField.becomeFirstResponder()
            registerForKeyboardNotifications()
          } else {
             // Not found, so remove keyboard.
             textField.resignFirstResponder()
            deregisterFromKeyboardNotifications()
          }
          // Do not add a line break
          return false
       }
    

}
