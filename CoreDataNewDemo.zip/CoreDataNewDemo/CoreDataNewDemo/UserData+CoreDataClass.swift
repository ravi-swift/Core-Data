//
//  UserData+CoreDataClass.swift
//  CoreDataNewDemo
//
//  Created by WeEnggs Technology on 08/01/20.
//  Copyright © 2020 WeEnggs Technology. All rights reserved.
//
//

import Foundation
import CoreData

@objc(UserData)
public class UserData: NSManagedObject {

}
