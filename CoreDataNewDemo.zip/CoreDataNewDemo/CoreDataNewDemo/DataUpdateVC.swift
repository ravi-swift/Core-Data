//
//  DataUpdateVC.swift
//  CoreDataNewDemo
//
//  Created by WeEnggs Technology on 07/01/20.
//  Copyright © 2020 WeEnggs Technology. All rights reserved.
//

import UIKit
import CoreData

var getrecord = NSManagedObject()

class DataUpdateVC: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var userIdTextField: UITextField!
    @IBOutlet weak var genserTextField: UITextField!
    @IBOutlet weak var userAgeTextField: UITextField!
    
    let nscontext = appdelegate?.persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userNameTextField.text = getrecord.value(forKey: "username") as? String
        passwordTextField.text = getrecord.value(forKey: "password") as? String
        userIdTextField.text = getrecord.value(forKey: "gender") as? String
        genserTextField.text = getrecord.value(forKey: "age") as? String
        userAgeTextField.text = getrecord.value(forKey: "userid") as? String
        
    }
    
    
    @IBAction func updateButton(_ sender: UIButton){
        let entrys = NSEntityDescription.entity(forEntityName: "UserData", in: nscontext!) // coredata name
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserData")
        request.entity = entrys
        
        let predi1 = NSPredicate(format: "username =%@", userNameTextField.text!)
        let predi2 = NSPredicate(format: "password =%@", passwordTextField.text!)
        let predi3 = NSPredicate(format: "gender =%@", userIdTextField.text!)
        let predi4 = NSPredicate(format: "age =%@", genserTextField.text!)
        let predi5 = NSPredicate(format: "userid =%@", userAgeTextField.text!)
        let compoundPredi = NSCompoundPredicate(type: .and, subpredicates: [predi1,predi2,predi3,predi4,predi5])
        let fetchRequestSender = NSFetchRequest<NSFetchRequestResult>(entityName: "UserData")
        fetchRequestSender.predicate = compoundPredi
        
        do {
            let result = try nscontext?.fetch(request)
            if result?.count ?? 0 > 0 {
                let manage = getrecord
                manage.setValue(userNameTextField.text, forKey: "username")
                manage.setValue(passwordTextField.text, forKey: "password")
                manage.setValue(userIdTextField.text, forKey: "gender")
                manage.setValue(genserTextField.text, forKey: "age")
                manage.setValue(userAgeTextField.text, forKey: "userid")
                
                try nscontext?.save()
                self.navigationController?.popViewController(animated: true)
               // self.dismiss(animated: true, completion: nil)
            }
            else {
                print("Record Not Found")
            }
        } catch {
            
        }
    }
}
