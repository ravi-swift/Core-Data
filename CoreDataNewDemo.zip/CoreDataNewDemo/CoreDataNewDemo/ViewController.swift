//
//  ViewController.swift
//  CoreDataNewDemo
//
//  Created by WeEnggs Technology on 07/01/20.
//  Copyright © 2020 WeEnggs Technology. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var presentButton: UIButton!
    fileprivate var myArray = Array<Any>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
         let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserData")
               let context = appdelegate?.persistentContainer.viewContext
                      //request.predicate = NSPredicate(format: "age = %@", "12")
                      request.returnsObjectsAsFaults = false

                      do {
                       let result = try context?.fetch(request)
                          for data in result as! [NSManagedObject] {
                             print(data.value(forKey: "username") as! String)
                           print(data.value(forKey: "password") as! String)
                           print(data.value(forKey: "gender") as! String)
                           print(data.value(forKey: "age") as! String)
                           print(data.value(forKey: "userid") as! String)
                           myArray.append(data)
                        }
                      } catch {
                          print("Failed")
                      }
               self.tblView.reloadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        presentButton.sendActions(for: .touchUpInside)
    }
    
     @IBAction func reloadDataClicked(_ sender: UIButton) {
        self.tblView.reloadData()
    }

    @IBAction func PushButtonClicked(_ sender: UIButton) {
        let inserVC = self.storyboard?.instantiateViewController(withIdentifier: "InsertDataVCViewController") as! InsertDataVCViewController
        self.navigationController?.pushViewController(inserVC, animated: true)
    }
    
    @IBAction func PresentButtonClicked(_ sender: UIButton) {
        myArray.removeAll()
         let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserData")
        let context = appdelegate?.persistentContainer.viewContext
               //request.predicate = NSPredicate(format: "age = %@", "12")
               request.returnsObjectsAsFaults = false

               do {
                let result = try context?.fetch(request)
                   for data in result as! [NSManagedObject] {
                    print(data.value(forKey: "username") as! String)
                    print(data.value(forKey: "password") as! String)
                    print(data.value(forKey: "gender") as! String)
                    print(data.value(forKey: "age") as! String)
                    print(data.value(forKey: "userid") as! String)
                    myArray.append(data)
                 }
               } catch {
                   print("Failed")
               }
        self.tblView.reloadData()
    }
    
}

extension ViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let lblName = cell.contentView.viewWithTag(10) as! UILabel
        let lblPass = cell.contentView.viewWithTag(20) as! UILabel
        let lblGender = cell.contentView.viewWithTag(30) as! UILabel
        let lblID = cell.contentView.viewWithTag(40) as! UILabel
        let lblAge = cell.contentView.viewWithTag(50) as! UILabel
        
        let dic = myArray[indexPath.row] as AnyObject
        lblName.text = "username: \(String(describing: dic.value(forKey: "username") ?? ""))"
        lblPass.text = "password: \(String(describing: dic.value(forKey: "password") ?? ""))"
        lblGender.text = "userid: \(String(describing: dic.value(forKey: "gender") ?? ""))"
        lblAge.text = "gender: \(String(describing: dic.value(forKey: "age") ?? ""))"
        lblID.text = "age: \(String(describing: dic.value(forKey: "userid") ?? "" ))"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 254
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 254
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?
    {
        let deleteAction = UITableViewRowAction(style: .default, title: "Delete", handler: { (action, indexPath) in
        // remove the deleted item from the model
        let context = appdelegate?.persistentContainer.viewContext
        do {
            context?.delete(self.myArray[indexPath.row] as! NSManagedObject)
            self.myArray.remove(at: indexPath.row)
            try context?.save()
            print("Record Deleted")
        } catch {
            print("Record Not Found")
        }
        
                  //tableView.reloadData()
                   // remove the deleted item from the `UITableView`
        self.tblView.deleteRows(at: [indexPath], with: .fade)
        })
  /*      let deleteAction = UITableViewRowAction(style: .default, title: "Delete", handler: { (action, indexPath) in
       //     let temp = self.item[indexPath.row] as! NSManagedObject

            let context = appdelegate?.persistentContainer.viewContext
            let entitydec = NSEntityDescription.entity(forEntityName: "UserData", in: context!)
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserData")
            request.entity = entitydec
            /*
            let userNAME = temp.value(forKey: "email")
            let password = temp.value(forKey: "password")
            let pred = NSPredicate(format: "email = %@", userNAME as! CVarArg)
             let pred1 = NSPredicate(format: "password = %@", password as! CVarArg)
            let andPredicate = NSCompoundPredicate(type: .and, subpredicates: [pred,pred1])
            request.predicate = andPredicate */
            do
            {
                let result = try context?.fetch(request)
                if result?.count ?? 0 > 0
                {
                    let manage = result?[0] as! NSManagedObject
                    context?.delete(manage)
                    try context?.save()
                    print("Record Deleted")
                }
                else
                {
                    print("Record Not Found")
                }
            }
            catch {
                
            }
            self.myArray.remove(at: indexPath.row)
            self.tblView.deleteRows(at: [indexPath], with: .middle)
            self.tblView.reloadData()
        })*/
        return [deleteAction]
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let updatevc = self.storyboard?.instantiateViewController(withIdentifier: "DataUpdateVC") as! DataUpdateVC
        let temp = myArray[indexPath.row] as! NSManagedObject
        getrecord = temp 
        self.tblView.reloadData()
        self.navigationController?.pushViewController(updatevc, animated: true)
       // self.present(updatevc, animated: true, completion: nil)
    }
    
}

extension UIView {
    
    @IBInspectable
    var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
        }
    }
    @IBInspectable
    var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    @IBInspectable
    var borderColor: UIColor? {
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.borderColor = color.cgColor
            } else {
                layer.borderColor = nil
            }
        }
    }
}
