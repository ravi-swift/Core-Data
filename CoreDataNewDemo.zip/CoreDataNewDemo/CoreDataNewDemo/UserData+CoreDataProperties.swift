//
//  UserData+CoreDataProperties.swift
//  CoreDataNewDemo
//
//  Created by WeEnggs Technology on 08/01/20.
//  Copyright © 2020 WeEnggs Technology. All rights reserved.
//
//

import Foundation
import CoreData


extension UserData {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<UserData> {
        return NSFetchRequest<UserData>(entityName: "UserData")
    }

    @NSManaged public var age: String?
    @NSManaged public var gender: String?
    @NSManaged public var password: String?
    @NSManaged public var userid: String?
    @NSManaged public var username: String?

}
