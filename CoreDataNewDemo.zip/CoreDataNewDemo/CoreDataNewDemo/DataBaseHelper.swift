//
//  DataBaseHelper.swift
//  CoreDataNewDemo
//
//  Created by WeEnggs Technology on 08/01/20.
//  Copyright © 2020 WeEnggs Technology. All rights reserved.
//

import Foundation
import CoreData

class DataBaseHelper {
     
    static var shared = DataBaseHelper()
    let context = appdelegate?.persistentContainer.viewContext
    
    func save(object: [String:Any]) {
        let userEntrys = NSEntityDescription.insertNewObject(forEntityName: "UserData", into: context!) as! UserData// coredata name
        userEntrys.username = object["username"] as! String
        userEntrys.password = object["password"]as! String
        userEntrys.gender = object["gender"]as! String
        userEntrys.age = object["age"]as! String
        userEntrys.userid = object["userid"]as! String
    }
}
